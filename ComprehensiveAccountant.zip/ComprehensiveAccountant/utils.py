from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from io import BytesIO
from datetime import datetime, timedelta
from models import Sale, Purchase, Product, Customer, Supplier
from sqlalchemy import func
from app import db

def generate_invoice_pdf(sale, company):
    """Generate PDF invoice for a sale"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    
    # Build the content
    story = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1,  # Center alignment
    )
    
    story.append(Paragraph(f"فاتورة مبيعات رقم: {sale.invoice_number}", title_style))
    story.append(Spacer(1, 12))
    
    # Company info
    if company:
        company_info = f"""
        <b>{company.name}</b><br/>
        {company.address or ''}<br/>
        الهاتف: {company.phone or ''}<br/>
        البريد الإلكتروني: {company.email or ''}<br/>
        الرقم الضريبي: {company.tax_number or ''}
        """
        story.append(Paragraph(company_info, styles['Normal']))
        story.append(Spacer(1, 12))
    
    # Customer info
    if sale.customer:
        customer_info = f"العميل: {sale.customer.name}"
        if sale.customer.phone:
            customer_info += f" - الهاتف: {sale.customer.phone}"
        story.append(Paragraph(customer_info, styles['Normal']))
        story.append(Spacer(1, 12))
    
    # Invoice date
    story.append(Paragraph(f"تاريخ الفاتورة: {sale.sale_date.strftime('%Y-%m-%d')}", styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Items table
    data = [['المنتج', 'الكمية', 'سعر الوحدة', 'الإجمالي']]
    
    for item in sale.items:
        data.append([
            item.product.name,
            str(item.quantity),
            f"{item.unit_price:.2f}",
            f"{item.total_price:.2f}"
        ])
    
    # Add totals
    data.append(['', '', 'المجموع الفرعي:', f"{sale.total_amount:.2f}"])
    if sale.discount_amount > 0:
        data.append(['', '', 'الخصم:', f"-{sale.discount_amount:.2f}"])
    if sale.tax_amount > 0:
        data.append(['', '', 'الضريبة:', f"{sale.tax_amount:.2f}"])
    data.append(['', '', 'المجموع النهائي:', f"{sale.net_amount:.2f}"])
    
    table = Table(data, colWidths=[6*cm, 3*cm, 3*cm, 3*cm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(table)
    
    # Notes
    if sale.notes:
        story.append(Spacer(1, 20))
        story.append(Paragraph(f"ملاحظات: {sale.notes}", styles['Normal']))
    
    doc.build(story)
    
    pdf = buffer.getvalue()
    buffer.close()
    
    return pdf

def get_dashboard_data():
    """Get dashboard statistics and data"""
    # Sales data
    today_sales = db.session.query(func.sum(Sale.net_amount)).filter(
        func.date(Sale.sale_date) == datetime.now().date()
    ).scalar() or 0
    
    month_sales = db.session.query(func.sum(Sale.net_amount)).filter(
        func.extract('month', Sale.sale_date) == datetime.now().month,
        func.extract('year', Sale.sale_date) == datetime.now().year
    ).scalar() or 0
    
    # Purchase data
    month_purchases = db.session.query(func.sum(Purchase.net_amount)).filter(
        func.extract('month', Purchase.purchase_date) == datetime.now().month,
        func.extract('year', Purchase.purchase_date) == datetime.now().year
    ).scalar() or 0
    
    # Product counts
    total_products = Product.query.count()
    low_stock_products = Product.query.filter(Product.quantity <= Product.min_quantity).count()
    
    # Customer count
    total_customers = Customer.query.count()
    
    # Recent sales for chart
    last_7_days = []
    sales_data = []
    for i in range(7):
        day = datetime.now().date() - timedelta(days=i)
        daily_sales = db.session.query(func.sum(Sale.net_amount)).filter(
            func.date(Sale.sale_date) == day
        ).scalar() or 0
        last_7_days.append(day.strftime('%Y-%m-%d'))
        sales_data.append(float(daily_sales))
    
    last_7_days.reverse()
    sales_data.reverse()
    
    return {
        'today_sales': today_sales,
        'month_sales': month_sales,
        'month_purchases': month_purchases,
        'total_products': total_products,
        'low_stock_products': low_stock_products,
        'total_customers': total_customers,
        'chart_dates': last_7_days,
        'chart_sales': sales_data
    }
