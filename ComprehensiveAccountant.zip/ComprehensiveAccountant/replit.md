# المحاسب الشامل (Comprehensive Accountant)

## Overview

This is a comprehensive accounting and inventory management system built with Flask and SQLAlchemy. The application provides Arabic RTL interface for managing sales, purchases, inventory, customers, suppliers, and financial reporting. It's designed for small to medium businesses that need a complete accounting solution with PDF invoice generation capabilities.

## System Architecture

### Backend Architecture
- **Framework**: Flask 3.1.1 with Python 3.11
- **Database ORM**: SQLAlchemy 2.0.41 with Flask-SQLAlchemy
- **Authentication**: Flask-Login for session management
- **PDF Generation**: ReportLab for invoice and report generation
- **Database**: SQLite (default) with PostgreSQL support ready
- **WSGI Server**: Gunicorn for production deployment

### Frontend Architecture
- **UI Framework**: Bootstrap 5.3.0 RTL for Arabic interface
- **Icons**: Font Awesome 6.4.0
- **Fonts**: Google Fonts (Tajawal) for Arabic typography
- **JavaScript**: Vanilla JS with Bootstrap components
- **Template Engine**: Jinja2 templates with Flask

### Database Design
The system uses a relational database with the following key entities:
- **Users**: Authentication and access control
- **Company**: Business information and branding
- **Customers**: Client management
- **Suppliers**: Vendor management
- **Products**: Inventory items with pricing
- **Sales**: Sales transactions and invoicing
- **Purchases**: Purchase orders and receiving

## Key Components

### 1. Authentication System
- Flask-Login implementation with user sessions
- Password hashing with Werkzeug security
- Admin role management
- Secure session handling with configurable secret keys

### 2. Inventory Management
- Product catalog with barcode support
- Stock quantity tracking
- Cost and selling price management
- Low stock alerts and notifications
- Unit of measure support

### 3. Sales Management
- Invoice generation with sequential numbering
- Customer association and management
- Discount calculation and tax handling
- PDF invoice generation with Arabic support
- Sales reporting and analytics

### 4. Purchase Management
- Purchase order creation
- Supplier management
- Automatic inventory updates
- Cost tracking and analysis

### 5. Financial Reporting
- Dashboard with key metrics
- Sales and purchase reports
- Profit/loss calculations
- Inventory valuation reports
- Date range filtering capabilities

### 6. PDF Generation
- Arabic-enabled invoice templates
- Company branding integration
- Professional invoice layouts
- Export capabilities for all reports

## Data Flow

1. **User Authentication**: Users log in through Flask-Login system
2. **Database Operations**: SQLAlchemy ORM handles all database interactions
3. **Business Logic**: Routes handle business operations and validations
4. **Template Rendering**: Jinja2 renders Arabic RTL templates
5. **PDF Generation**: ReportLab creates downloadable invoices and reports
6. **Session Management**: Flask sessions maintain user state

## External Dependencies

### Python Packages
- **flask**: Core web framework
- **flask-sqlalchemy**: Database ORM integration
- **flask-login**: User session management
- **werkzeug**: WSGI utilities and security
- **reportlab**: PDF generation
- **psycopg2-binary**: PostgreSQL database connector
- **gunicorn**: Production WSGI server
- **email-validator**: Email validation utilities

### Frontend Libraries
- **Bootstrap 5.3.0 RTL**: UI framework with Arabic support
- **Font Awesome 6.4.0**: Icon library
- **Google Fonts (Tajawal)**: Arabic typography

### System Dependencies (via Nix)
- **postgresql**: Database server
- **openssl**: Security and encryption
- **freetype**: Font rendering
- **glibcLocales**: Internationalization support

## Deployment Strategy

### Development Environment
- Local SQLite database for development
- Flask development server with hot reload
- Debug mode enabled for development

### Production Environment
- Gunicorn WSGI server with autoscale deployment
- PostgreSQL database for production data
- Environment-based configuration
- Proxy handling for reverse proxy setups

### Configuration Management
- Environment variables for sensitive data
- Database URL configuration
- Session secret management
- Connection pooling and health checks

### Scaling Considerations
- Database connection pooling configured
- Stateless application design for horizontal scaling
- File-based session storage (can be upgraded to Redis)
- Autoscale deployment target for traffic handling

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 25, 2025. Initial setup