from flask import render_template, request, redirect, url_for, flash, jsonify, make_response
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app import app, db
from models import *
from utils import generate_invoice_pdf, get_dashboard_data
from datetime import datetime, date
import json

@app.route('/')
@login_required
def dashboard():
    data = get_dashboard_data()
    return render_template('dashboard.html', data=data)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('اسم المستخدم أو كلمة المرور غير صحيحة', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Customer Management
@app.route('/customers')
@login_required
def customers():
    customers = Customer.query.all()
    return render_template('customers.html', customers=customers)

@app.route('/customers/add', methods=['POST'])
@login_required
def add_customer():
    name = request.form.get('name')
    phone = request.form.get('phone')
    email = request.form.get('email')
    address = request.form.get('address')
    
    customer = Customer(name=name, phone=phone, email=email, address=address)
    db.session.add(customer)
    db.session.commit()
    
    flash('تم إضافة العميل بنجاح', 'success')
    return redirect(url_for('customers'))

@app.route('/customers/edit/<int:id>', methods=['POST'])
@login_required
def edit_customer(id):
    customer = Customer.query.get_or_404(id)
    customer.name = request.form.get('name')
    customer.phone = request.form.get('phone')
    customer.email = request.form.get('email')
    customer.address = request.form.get('address')
    
    db.session.commit()
    flash('تم تحديث بيانات العميل بنجاح', 'success')
    return redirect(url_for('customers'))

@app.route('/customers/delete/<int:id>')
@login_required
def delete_customer(id):
    customer = Customer.query.get_or_404(id)
    db.session.delete(customer)
    db.session.commit()
    flash('تم حذف العميل بنجاح', 'success')
    return redirect(url_for('customers'))

# Supplier Management
@app.route('/suppliers')
@login_required
def suppliers():
    suppliers = Supplier.query.all()
    return render_template('suppliers.html', suppliers=suppliers)

@app.route('/suppliers/add', methods=['POST'])
@login_required
def add_supplier():
    name = request.form.get('name')
    phone = request.form.get('phone')
    email = request.form.get('email')
    address = request.form.get('address')
    
    supplier = Supplier(name=name, phone=phone, email=email, address=address)
    db.session.add(supplier)
    db.session.commit()
    
    flash('تم إضافة المورد بنجاح', 'success')
    return redirect(url_for('suppliers'))

@app.route('/suppliers/edit/<int:id>', methods=['POST'])
@login_required
def edit_supplier(id):
    supplier = Supplier.query.get_or_404(id)
    supplier.name = request.form.get('name')
    supplier.phone = request.form.get('phone')
    supplier.email = request.form.get('email')
    supplier.address = request.form.get('address')
    
    db.session.commit()
    flash('تم تحديث بيانات المورد بنجاح', 'success')
    return redirect(url_for('suppliers'))

@app.route('/suppliers/delete/<int:id>')
@login_required
def delete_supplier(id):
    supplier = Supplier.query.get_or_404(id)
    db.session.delete(supplier)
    db.session.commit()
    flash('تم حذف المورد بنجاح', 'success')
    return redirect(url_for('suppliers'))

# Product Management
@app.route('/products')
@login_required
def products():
    products = Product.query.all()
    return render_template('products.html', products=products)

@app.route('/products/add', methods=['POST'])
@login_required
def add_product():
    name = request.form.get('name')
    description = request.form.get('description')
    barcode = request.form.get('barcode')
    unit = request.form.get('unit')
    cost_price = float(request.form.get('cost_price', 0))
    selling_price = float(request.form.get('selling_price', 0))
    quantity = float(request.form.get('quantity', 0))
    min_quantity = float(request.form.get('min_quantity', 0))
    location = request.form.get('location')
    
    expiry_date = None
    if request.form.get('expiry_date'):
        expiry_date = datetime.strptime(request.form.get('expiry_date'), '%Y-%m-%d').date()
    
    product = Product(
        name=name, description=description, barcode=barcode, unit=unit,
        cost_price=cost_price, selling_price=selling_price, quantity=quantity,
        min_quantity=min_quantity, expiry_date=expiry_date, location=location
    )
    db.session.add(product)
    db.session.commit()
    
    flash('تم إضافة المنتج بنجاح', 'success')
    return redirect(url_for('products'))

@app.route('/products/edit/<int:id>', methods=['POST'])
@login_required
def edit_product(id):
    product = Product.query.get_or_404(id)
    product.name = request.form.get('name')
    product.description = request.form.get('description')
    product.barcode = request.form.get('barcode')
    product.unit = request.form.get('unit')
    product.cost_price = float(request.form.get('cost_price', 0))
    product.selling_price = float(request.form.get('selling_price', 0))
    product.quantity = float(request.form.get('quantity', 0))
    product.min_quantity = float(request.form.get('min_quantity', 0))
    product.location = request.form.get('location')
    
    if request.form.get('expiry_date'):
        product.expiry_date = datetime.strptime(request.form.get('expiry_date'), '%Y-%m-%d').date()
    
    db.session.commit()
    flash('تم تحديث بيانات المنتج بنجاح', 'success')
    return redirect(url_for('products'))

@app.route('/products/delete/<int:id>')
@login_required
def delete_product(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('تم حذف المنتج بنجاح', 'success')
    return redirect(url_for('products'))

# Sales Management
@app.route('/sales')
@login_required
def sales():
    sales = Sale.query.order_by(Sale.created_at.desc()).all()
    customers = Customer.query.all()
    products = Product.query.all()
    return render_template('sales.html', sales=sales, customers=customers, products=products)

@app.route('/sales/add', methods=['POST'])
@login_required
def add_sale():
    # Generate invoice number
    last_sale = Sale.query.order_by(Sale.id.desc()).first()
    invoice_number = f"INV-{(last_sale.id + 1 if last_sale else 1):06d}"
    
    customer_id = request.form.get('customer_id') or None
    discount_amount = float(request.form.get('discount_amount', 0))
    tax_amount = float(request.form.get('tax_amount', 0))
    notes = request.form.get('notes')
    
    # Create sale
    sale = Sale(
        invoice_number=invoice_number,
        customer_id=customer_id,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        notes=notes
    )
    
    db.session.add(sale)
    db.session.flush()  # Get the sale ID
    
    # Add sale items
    total_amount = 0
    products = request.form.getlist('product_id[]')
    quantities = request.form.getlist('quantity[]')
    prices = request.form.getlist('unit_price[]')
    
    for i, product_id in enumerate(products):
        if product_id and quantities[i] and prices[i]:
            quantity = float(quantities[i])
            unit_price = float(prices[i])
            total_price = quantity * unit_price
            
            # Create sale item
            sale_item = SaleItem(
                sale_id=sale.id,
                product_id=int(product_id),
                quantity=quantity,
                unit_price=unit_price,
                total_price=total_price
            )
            db.session.add(sale_item)
            
            # Update product quantity
            product = Product.query.get(product_id)
            product.quantity -= quantity
            
            total_amount += total_price
    
    # Update sale totals
    sale.total_amount = total_amount
    sale.net_amount = total_amount - discount_amount + tax_amount
    
    db.session.commit()
    flash('تم إضافة الفاتورة بنجاح', 'success')
    return redirect(url_for('sales'))

@app.route('/sales/invoice/<int:id>')
@login_required
def view_invoice(id):
    sale = Sale.query.get_or_404(id)
    company = Company.query.first()
    return render_template('invoice_template.html', sale=sale, company=company)

@app.route('/sales/pdf/<int:id>')
@login_required
def download_invoice_pdf(id):
    sale = Sale.query.get_or_404(id)
    company = Company.query.first()
    
    pdf_content = generate_invoice_pdf(sale, company)
    
    response = make_response(pdf_content)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=invoice_{sale.invoice_number}.pdf'
    
    return response

# Purchase Management
@app.route('/purchases')
@login_required
def purchases():
    purchases = Purchase.query.order_by(Purchase.created_at.desc()).all()
    suppliers = Supplier.query.all()
    products = Product.query.all()
    return render_template('purchases.html', purchases=purchases, suppliers=suppliers, products=products)

@app.route('/purchases/add', methods=['POST'])
@login_required
def add_purchase():
    # Generate invoice number
    last_purchase = Purchase.query.order_by(Purchase.id.desc()).first()
    invoice_number = f"PUR-{(last_purchase.id + 1 if last_purchase else 1):06d}"
    
    supplier_id = request.form.get('supplier_id') or None
    discount_amount = float(request.form.get('discount_amount', 0))
    tax_amount = float(request.form.get('tax_amount', 0))
    notes = request.form.get('notes')
    
    # Create purchase
    purchase = Purchase(
        invoice_number=invoice_number,
        supplier_id=supplier_id,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        notes=notes
    )
    
    db.session.add(purchase)
    db.session.flush()  # Get the purchase ID
    
    # Add purchase items
    total_amount = 0
    products = request.form.getlist('product_id[]')
    quantities = request.form.getlist('quantity[]')
    prices = request.form.getlist('unit_price[]')
    
    for i, product_id in enumerate(products):
        if product_id and quantities[i] and prices[i]:
            quantity = float(quantities[i])
            unit_price = float(prices[i])
            total_price = quantity * unit_price
            
            # Create purchase item
            purchase_item = PurchaseItem(
                purchase_id=purchase.id,
                product_id=int(product_id),
                quantity=quantity,
                unit_price=unit_price,
                total_price=total_price
            )
            db.session.add(purchase_item)
            
            # Update product quantity and cost
            product = Product.query.get(product_id)
            product.quantity += quantity
            product.cost_price = unit_price
            
            total_amount += total_price
    
    # Update purchase totals
    purchase.total_amount = total_amount
    purchase.net_amount = total_amount - discount_amount + tax_amount
    
    db.session.commit()
    flash('تم إضافة فاتورة الشراء بنجاح', 'success')
    return redirect(url_for('purchases'))

# Inventory Management
@app.route('/inventory')
@login_required
def inventory():
    products = Product.query.all()
    low_stock_products = Product.query.filter(Product.quantity <= Product.min_quantity).all()
    return render_template('inventory.html', products=products, low_stock_products=low_stock_products)

# Reports
@app.route('/reports')
@login_required
def reports():
    return render_template('reports.html')

@app.route('/reports/sales')
@login_required
def sales_report():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Sale.query
    if start_date:
        query = query.filter(Sale.sale_date >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(Sale.sale_date <= datetime.strptime(end_date, '%Y-%m-%d'))
    
    sales = query.all()
    total_sales = sum(sale.net_amount for sale in sales)
    
    return jsonify({
        'sales': [{'invoice_number': s.invoice_number, 'amount': s.net_amount, 'date': s.sale_date.strftime('%Y-%m-%d')} for s in sales],
        'total': total_sales
    })

# Company Settings
@app.route('/company')
@login_required
def company_settings():
    company = Company.query.first()
    return render_template('company.html', company=company)

@app.route('/company/update', methods=['POST'])
@login_required
def update_company():
    company = Company.query.first()
    if not company:
        company = Company()
        db.session.add(company)
    
    company.name = request.form.get('name')
    company.address = request.form.get('address')
    company.phone = request.form.get('phone')
    company.email = request.form.get('email')
    company.tax_number = request.form.get('tax_number')
    
    db.session.commit()
    flash('تم تحديث بيانات الشركة بنجاح', 'success')
    return redirect(url_for('company_settings'))
