// Main JavaScript file for المحاسب الشامل (Comprehensive Accountant)

document.addEventListener('DOMContentLoaded', function() {
    // Initialize application
    initializeApp();
    
    // Setup form validations
    setupFormValidations();
    
    // Setup tooltips and popovers
    setupBootstrapComponents();
    
    // Setup number formatting
    setupNumberFormatting();
    
    // Setup auto-save functionality
    setupAutoSave();
    
    // Setup keyboard shortcuts
    setupKeyboardShortcuts();
});

/**
 * Initialize the application
 */
function initializeApp() {
    console.log('تم تحميل المحاسب الشامل بنجاح');
    
    // Add loading states to buttons
    setupLoadingStates();
    
    // Setup real-time updates
    setupRealTimeUpdates();
    
    // Setup notifications
    setupNotifications();
    
    // Setup theme management
    setupThemeManagement();
    
    // Setup sidebar functionality
    setupSidebar();
}

/**
 * Setup form validations
 */
function setupFormValidations() {
    // Bootstrap validation
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Focus on first invalid field
                const firstInvalid = form.querySelector('.form-control:invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                    showNotification('يرجى تصحيح الأخطاء المحددة', 'error');
                }
            }
            form.classList.add('was-validated');
        });
    });
    
    // Real-time validation
    const inputs = document.querySelectorAll('.form-control');
    inputs.forEach(input => {
        input.addEventListener('blur', validateField);
        input.addEventListener('input', clearFieldError);
    });
}

/**
 * Validate individual field
 */
function validateField(event) {
    const field = event.target;
    const value = field.value.trim();
    
    // Clear previous errors
    clearFieldError(event);
    
    // Custom validations
    if (field.type === 'email' && value && !isValidEmail(value)) {
        showFieldError(field, 'البريد الإلكتروني غير صحيح');
        return false;
    }
    
    if (field.type === 'tel' && value && !isValidPhone(value)) {
        showFieldError(field, 'رقم الهاتف غير صحيح');
        return false;
    }
    
    if (field.name === 'tax_number' && value && !isValidTaxNumber(value)) {
        showFieldError(field, 'الرقم الضريبي غير صحيح');
        return false;
    }
    
    return true;
}

/**
 * Clear field error
 */
function clearFieldError(event) {
    const field = event.target;
    const errorElement = field.parentNode.querySelector('.invalid-feedback');
    
    field.classList.remove('is-invalid');
    if (errorElement) {
        errorElement.remove();
    }
}

/**
 * Show field error
 */
function showFieldError(field, message) {
    field.classList.add('is-invalid');
    
    // Remove existing error
    const existingError = field.parentNode.querySelector('.invalid-feedback');
    if (existingError) {
        existingError.remove();
    }
    
    // Add new error
    const errorElement = document.createElement('div');
    errorElement.className = 'invalid-feedback';
    errorElement.textContent = message;
    field.parentNode.appendChild(errorElement);
}

/**
 * Setup Bootstrap components
 */
function setupBootstrapComponents() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

/**
 * Setup number formatting for Arabic locale
 */
function setupNumberFormatting() {
    const numberInputs = document.querySelectorAll('input[type="number"], .number-format');
    
    numberInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value) {
                const number = parseFloat(this.value);
                if (!isNaN(number)) {
                    this.value = formatNumber(number);
                }
            }
        });
        
        input.addEventListener('focus', function() {
            // Remove formatting for editing
            this.value = this.value.replace(/,/g, '');
        });
    });
}

/**
 * Format number with commas
 */
function formatNumber(number, decimals = 2) {
    return new Intl.NumberFormat('ar-SA', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    }).format(number);
}

/**
 * Format currency
 */
function formatCurrency(amount, currency = 'SAR') {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

/**
 * Setup loading states for buttons
 */
function setupLoadingStates() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            const submitButton = this.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>جاري المعالجة...';
                
                // Re-enable after 3 seconds as fallback
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.innerHTML = submitButton.getAttribute('data-original-text') || 'حفظ';
                }, 3000);
            }
        });
    });
}

/**
 * Setup auto-save functionality
 */
function setupAutoSave() {
    const autoSaveForms = document.querySelectorAll('.auto-save');
    
    autoSaveForms.forEach(form => {
        let autoSaveTimeout;
        
        form.addEventListener('input', function() {
            clearTimeout(autoSaveTimeout);
            autoSaveTimeout = setTimeout(() => {
                saveFormDraft(form);
            }, 2000); // Auto-save after 2 seconds of inactivity
        });
    });
}

/**
 * Save form draft to localStorage
 */
function saveFormDraft(form) {
    const formId = form.id || 'unnamed-form';
    const formData = new FormData(form);
    const draftData = {};
    
    for (let [key, value] of formData.entries()) {
        draftData[key] = value;
    }
    
    localStorage.setItem(`draft_${formId}`, JSON.stringify(draftData));
    showNotification('تم حفظ المسودة تلقائياً', 'info', 2000);
}

/**
 * Load form draft from localStorage
 */
function loadFormDraft(formId) {
    const draftData = localStorage.getItem(`draft_${formId}`);
    if (draftData) {
        const data = JSON.parse(draftData);
        const form = document.getElementById(formId);
        
        if (form) {
            Object.keys(data).forEach(key => {
                const field = form.querySelector(`[name="${key}"]`);
                if (field) {
                    field.value = data[key];
                }
            });
        }
    }
}

/**
 * Clear form draft
 */
function clearFormDraft(formId) {
    localStorage.removeItem(`draft_${formId}`);
}

/**
 * Setup keyboard shortcuts
 */
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(event) {
        // Ctrl+S or Cmd+S to save
        if ((event.ctrlKey || event.metaKey) && event.key === 's') {
            event.preventDefault();
            const form = document.querySelector('form');
            if (form) {
                form.dispatchEvent(new Event('submit'));
            }
        }
        
        // Escape to close modals
        if (event.key === 'Escape') {
            const openModal = document.querySelector('.modal.show');
            if (openModal) {
                const modal = bootstrap.Modal.getInstance(openModal);
                if (modal) {
                    modal.hide();
                }
            }
        }
        
        // F1 for help (if implemented)
        if (event.key === 'F1') {
            event.preventDefault();
            showHelp();
        }
    });
}

/**
 * Setup notifications system
 */
function setupNotifications() {
    // Create notification container if it doesn't exist
    if (!document.getElementById('notification-container')) {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.className = 'position-fixed top-0 start-50 translate-middle-x p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
    }
}

/**
 * Show notification
 */
function showNotification(message, type = 'info', duration = 5000) {
    const container = document.getElementById('notification-container');
    const notification = document.createElement('div');
    
    const alertClass = type === 'error' ? 'alert-danger' : 
                      type === 'success' ? 'alert-success' : 
                      type === 'warning' ? 'alert-warning' : 'alert-info';
    
    notification.className = `alert ${alertClass} alert-dismissible fade show`;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    container.appendChild(notification);
    
    // Auto-remove after duration
    setTimeout(() => {
        if (notification.parentNode) {
            const bsAlert = new bootstrap.Alert(notification);
            bsAlert.close();
        }
    }, duration);
}

/**
 * Setup real-time updates
 */
function setupRealTimeUpdates() {
    // Update timestamps
    setInterval(updateTimestamps, 60000); // Every minute
    
    // Check for low stock alerts
    setInterval(checkLowStockAlerts, 300000); // Every 5 minutes
}

/**
 * Update relative timestamps
 */
function updateTimestamps() {
    const timestamps = document.querySelectorAll('.timestamp');
    timestamps.forEach(timestamp => {
        const date = new Date(timestamp.dataset.date);
        timestamp.textContent = getRelativeTime(date);
    });
}

/**
 * Get relative time in Arabic
 */
function getRelativeTime(date) {
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'الآن';
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    if (days < 30) return `منذ ${days} يوم`;
    
    return date.toLocaleDateString('ar-SA');
}

/**
 * Check for low stock alerts
 */
function checkLowStockAlerts() {
    // This would typically fetch from the server
    // For now, we'll check if we're on the inventory page
    if (window.location.pathname.includes('inventory')) {
        const lowStockItems = document.querySelectorAll('.table-warning');
        if (lowStockItems.length > 0) {
            showNotification(`تحذير: ${lowStockItems.length} منتج بكمية قليلة`, 'warning');
        }
    }
}

/**
 * Setup theme management
 */
function setupThemeManagement() {
    // Check for saved theme preference or default to light mode
    const currentTheme = localStorage.getItem('theme') || 'light';
    applyTheme(currentTheme);
    
    // Add theme toggle if it exists
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
}

/**
 * Apply theme
 */
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}

/**
 * Toggle theme
 */
function toggleTheme() {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(newTheme);
}

/**
 * Validation helpers
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[0-9\s\-\(\)]{8,}$/;
    return phoneRegex.test(phone);
}

function isValidTaxNumber(taxNumber) {
    // Basic validation for Saudi tax number format
    const taxRegex = /^[0-9]{15}$/;
    return taxRegex.test(taxNumber);
}

/**
 * Show help modal
 */
function showHelp() {
    showNotification('قريباً: دليل المساعدة', 'info');
}

/**
 * Export utilities for other scripts
 */
window.AccountingApp = {
    formatNumber,
    formatCurrency,
    showNotification,
    validateField,
    saveFormDraft,
    loadFormDraft,
    clearFormDraft,
    getRelativeTime
};

/**
 * Chart.js Arabic configuration
 */
if (typeof Chart !== 'undefined') {
    Chart.defaults.font.family = 'Tajawal, sans-serif';
    Chart.defaults.locale = 'ar-SA';
    
    // RTL support for charts
    Chart.defaults.plugins.legend.rtl = true;
    Chart.defaults.plugins.tooltip.rtl = true;
}

/**
 * Print functionality
 */
function printInvoice(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <title>طباعة الفاتورة</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
                <link href="/static/css/style.css" rel="stylesheet">
                <style>
                    @media print { .no-print { display: none !important; } }
                </style>
            </head>
            <body>
                ${element.innerHTML}
                <script>
                    window.onload = function() {
                        window.print();
                        window.close();
                    };
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    }
}

/**
 * Confirm action with Arabic text
 */
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

/**
 * Format date for Arabic locale
 */
function formatDate(date, format = 'full') {
    const options = {
        full: { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            weekday: 'long'
        },
        short: { 
            year: 'numeric', 
            month: '2-digit', 
            day: '2-digit' 
        },
        time: { 
            hour: '2-digit', 
            minute: '2-digit' 
        }
    };
    
    return new Intl.DateTimeFormat('ar-SA', options[format]).format(new Date(date));
}

// Make functions globally available
window.printInvoice = printInvoice;
window.confirmAction = confirmAction;
window.formatDate = formatDate;

/**
 * Setup sidebar functionality
 */
function setupSidebar() {
    // Mark active menu item
    const currentPath = window.location.pathname;
    const sidebarLinks = document.querySelectorAll('.sidebar-nav .nav-link');
    
    sidebarLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
            
            // If it's a sub-item, expand the parent menu
            const parentCollapse = link.closest('.collapse');
            if (parentCollapse) {
                parentCollapse.classList.add('show');
                const parentToggle = document.querySelector(`[data-bs-target="#${parentCollapse.id}"]`);
                if (parentToggle) {
                    parentToggle.setAttribute('aria-expanded', 'true');
                }
            }
        }
    });
    
    // Auto-close sidebar on mobile after clicking a link
    const sidebarElement = document.getElementById('sidebar');
    if (sidebarElement) {
        sidebarLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                // Don't close for parent links or dashboard
                if (!this.classList.contains('parent-link') && !this.closest('.dashboard-item')) {
                    if (window.innerWidth < 992) {
                        const sidebar = bootstrap.Offcanvas.getInstance(sidebarElement);
                        if (sidebar) {
                            setTimeout(() => sidebar.hide(), 150);
                        }
                    }
                }
            });
        });
    }
    
    // Handle add button clicks
    const addButtons = document.querySelectorAll('.add-btn');
    addButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
        });
    });
    
    // Add smooth hover effects for main nav items
    const mainNavLinks = document.querySelectorAll('.sidebar-nav .nav-link:not(.sub-item .nav-link)');
    mainNavLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            if (!this.classList.contains('active') && !this.classList.contains('parent-link')) {
                this.style.transform = 'translateX(-3px)';
            }
        });
        
        link.addEventListener('mouseleave', function() {
            if (!this.classList.contains('active') && !this.classList.contains('parent-link')) {
                this.style.transform = 'translateX(0)';
            }
        });
    });
}

/**
 * Open quick add modal
 */
function openQuickAddModal(type) {
    const modal = new bootstrap.Modal(document.getElementById('quickAddModal'));
    const modalTitle = document.getElementById('quickAddModalLabel');
    const modalBody = document.getElementById('quickAddModalBody');
    
    let title = '';
    let content = '';
    
    switch(type) {
        case 'customer':
            title = 'إضافة عميل جديد';
            content = `
                <form id="quickCustomerForm" class="row g-3">
                    <div class="col-md-6">
                        <label for="customerName" class="form-label">اسم العميل *</label>
                        <input type="text" class="form-control" id="customerName" required>
                    </div>
                    <div class="col-md-6">
                        <label for="customerPhone" class="form-label">رقم الهاتف</label>
                        <input type="tel" class="form-control" id="customerPhone">
                    </div>
                    <div class="col-md-6">
                        <label for="customerEmail" class="form-label">البريد الإلكتروني</label>
                        <input type="email" class="form-control" id="customerEmail">
                    </div>
                    <div class="col-md-6">
                        <label for="customerAddress" class="form-label">العنوان</label>
                        <input type="text" class="form-control" id="customerAddress">
                    </div>
                    <div class="col-12">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                            <button type="submit" class="btn btn-primary">حفظ العميل</button>
                        </div>
                    </div>
                </form>
            `;
            break;
            
        case 'invoice':
            title = 'إنشاء فاتورة مبيعات جديدة';
            content = `
                <div class="text-center">
                    <i class="fas fa-file-invoice fa-4x text-primary mb-3"></i>
                    <h5>إنشاء فاتورة مبيعات</h5>
                    <p class="text-muted">سيتم توجيهك إلى صفحة إنشاء فاتورة جديدة</p>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="button" class="btn btn-primary" onclick="window.location.href='${window.location.origin}/add_sale'">إنشاء فاتورة</button>
                    </div>
                </div>
            `;
            break;
            
        case 'payment':
            title = 'إضافة سند عميل';
            content = `
                <form id="quickPaymentForm" class="row g-3">
                    <div class="col-md-6">
                        <label for="paymentCustomer" class="form-label">العميل *</label>
                        <select class="form-select" id="paymentCustomer" required>
                            <option value="">اختر العميل</option>
                            <!-- سيتم تحميل العملاء ديناميكياً -->
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="paymentAmount" class="form-label">المبلغ *</label>
                        <input type="number" class="form-control" id="paymentAmount" step="0.01" required>
                    </div>
                    <div class="col-md-6">
                        <label for="paymentMethod" class="form-label">طريقة الدفع</label>
                        <select class="form-select" id="paymentMethod">
                            <option value="نقد">نقد</option>
                            <option value="بنك">تحويل بنكي</option>
                            <option value="شيك">شيك</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="paymentDate" class="form-label">تاريخ الدفع</label>
                        <input type="date" class="form-control" id="paymentDate" value="${new Date().toISOString().split('T')[0]}">
                    </div>
                    <div class="col-12">
                        <label for="paymentNotes" class="form-label">ملاحظات</label>
                        <textarea class="form-control" id="paymentNotes" rows="2"></textarea>
                    </div>
                    <div class="col-12">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                            <button type="submit" class="btn btn-primary">حفظ السند</button>
                        </div>
                    </div>
                </form>
            `;
            break;
    }
    
    modalTitle.textContent = title;
    modalBody.innerHTML = content;
    modal.show();
    
    // Setup form handlers
    setupQuickAddForms(type);
}

/**
 * Setup quick add form handlers
 */
function setupQuickAddForms(type) {
    if (type === 'customer') {
        const form = document.getElementById('quickCustomerForm');
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                submitQuickCustomer();
            });
        }
    } else if (type === 'payment') {
        const form = document.getElementById('quickPaymentForm');
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                submitQuickPayment();
            });
        }
        // Load customers for payment form
        loadCustomersForPayment();
    }
}

/**
 * Submit quick customer form
 */
function submitQuickCustomer() {
    const formData = new FormData();
    formData.append('name', document.getElementById('customerName').value);
    formData.append('phone', document.getElementById('customerPhone').value);
    formData.append('email', document.getElementById('customerEmail').value);
    formData.append('address', document.getElementById('customerAddress').value);
    
    fetch('/add_customer', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('تم إضافة العميل بنجاح', 'success');
            bootstrap.Modal.getInstance(document.getElementById('quickAddModal')).hide();
        } else {
            showNotification('حدث خطأ في إضافة العميل', 'error');
        }
    })
    .catch(error => {
        showNotification('حدث خطأ في الاتصال', 'error');
    });
}

/**
 * Submit quick payment form
 */
function submitQuickPayment() {
    const formData = new FormData();
    formData.append('customer_id', document.getElementById('paymentCustomer').value);
    formData.append('amount', document.getElementById('paymentAmount').value);
    formData.append('payment_method', document.getElementById('paymentMethod').value);
    formData.append('payment_date', document.getElementById('paymentDate').value);
    formData.append('notes', document.getElementById('paymentNotes').value);
    
    // This would need a backend route to handle payment creation
    showNotification('سيتم إضافة هذه الميزة قريباً', 'info');
    bootstrap.Modal.getInstance(document.getElementById('quickAddModal')).hide();
}

/**
 * Load customers for payment form
 */
function loadCustomersForPayment() {
    fetch('/api/customers')
    .then(response => response.json())
    .then(customers => {
        const select = document.getElementById('paymentCustomer');
        if (select && customers) {
            customers.forEach(customer => {
                const option = document.createElement('option');
                option.value = customer.id;
                option.textContent = customer.name;
                select.appendChild(option);
            });
        }
    })
    .catch(error => {
        console.log('Could not load customers');
    });
}

// Make function globally available
window.openQuickAddModal = openQuickAddModal;

console.log('تم تحميل جميع وظائف JavaScript بنجاح');
